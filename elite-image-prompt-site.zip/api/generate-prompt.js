import { OpenAI } from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export default async function handler(req, res) {
  const { idea } = req.body;

  const chatResponse = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [
      {
        role: 'system',
        content: 'You are the world’s top image prompt engineer. Based on the user’s idea, write the most powerful and cinematic image generation prompt possible for ChatGPT/DALL·E 3. Capture ultra-specific detail, lighting, composition, and realism. Do not repeat the user’s words — expand and elevate them. Do not mention you are AI.',
      },
      {
        role: 'user',
        content: idea
      }
    ],
    temperature: 0.9
  });

  const prompt = chatResponse.choices[0].message.content;
  res.status(200).json({ prompt });
}